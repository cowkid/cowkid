<!doctype html>
<form method="get" id="search" action="http://duckduckgo.com/">
  <input placeholder="click here and press enter&hellip;" /> LOAD UNSAFE SCRIPS, OR DUCKDUCKGO WONT CONNECT! also change the view!
</form>
